import java.util.*;

public class BackChat {
    // Global network to store all users by username.
    private static Map<String, User> network = new HashMap<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        // Create the current user based on input.
        System.out.print("Enter your username: ");
        String username = scanner.nextLine();
        User currentUser = new User(username);
        network.put(username, currentUser);

        boolean exit = false;
        while (!exit) {
            System.out.println("\n--- Main Menu ---");
            System.out.println("1. View Friend List");
            System.out.println("2. Add Friend");
            System.out.println("3. Delete Friend");
            System.out.println("4. View a Friend's Friends");
            System.out.println("5. Exit");
            System.out.print("Select an option: ");
            int option = -1;
            try {
                option = scanner.nextInt();
                scanner.nextLine(); // consume newline
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // consume invalid input
                continue;
            }

            switch (option) {
                case 1:
                    currentUser.viewFriends();
                    break;
                case 2:
                    addFriend(currentUser);
                    break;
                case 3:
                    deleteFriend(currentUser);
                    break;
                case 4:
                    viewFriendOfFriend(currentUser);
                    break;
                case 5:
                    exit = true;
                    System.out.println("Exiting BackChat. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Please select a valid option.");
            }
        }
    }

    /**
     * Prompts the user to enter a friend's username and adds that friend.
     * If the friend does not exist in the network, a new user is created.
     */
    private static void addFriend(User currentUser) {
        System.out.print("Enter the username of the friend to add: ");
        String friendUsername = scanner.nextLine();
        User friend;
        if (network.containsKey(friendUsername)) {
            friend = network.get(friendUsername);
        } else {
            friend = new User(friendUsername);
            network.put(friendUsername, friend);
        }
        currentUser.addFriendMutual(friend);
    }

    /**
     * Allows the user to delete a friend from their friend list.
     */
    private static void deleteFriend(User currentUser) {
        System.out.println("Select a friend to remove:");
        User friend = currentUser.selectFriend(scanner);
        if (friend != null) {
            currentUser.deleteFriendMutual(friend);
        }
    }

    /**
     * Allows the user to view the friend list of one of their friends.
     */
    private static void viewFriendOfFriend(User currentUser) {
        System.out.println("Select a friend to view their friends:");
        User friend = currentUser.selectFriend(scanner);
        if (friend != null) {
            friend.viewFriends();
        }
    }
}