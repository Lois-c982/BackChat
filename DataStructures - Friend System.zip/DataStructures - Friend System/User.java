import java.util.*;

class User {
    private String username;
    private Map<String, String> details;
    private List<User> friends;

    public User(String username) {
        this.username = username;
        this.details = new HashMap<>();
        this.friends = new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }

    /**
     * Adds a friend mutually (i.e., both users become friends).
     */
    public void addFriendMutual(User friend) {
        if (friend == this) {
            System.out.println("You cannot add yourself as a friend.");
            return;
        }
        if (!friends.contains(friend)) {
            friends.add(friend);
            // Add current user to the friend's list if not already added.
            if (!friend.friends.contains(this)) {
                friend.friends.add(this);
            }
            System.out.println(friend.getUsername() + " has been added as a friend.");
        } else {
            System.out.println(friend.getUsername() + " is already your friend.");
        }
    }

    /**
     * Deletes a friend mutually (i.e., both users lose the connection).
     */
    public void deleteFriendMutual(User friend) {
        if (friends.contains(friend)) {
            friends.remove(friend);
            // Remove current user from the friend's list if present.
            if (friend.friends.contains(this)) {
                friend.friends.remove(this);
            }
            System.out.println(friend.getUsername() + " has been removed from your friend list.");
        } else {
            System.out.println(friend.getUsername() + " is not in your friend list.");
        }
    }

    /**
     * Displays all friends of the user.
     */
    public void viewFriends() {
        if (friends.isEmpty()) {
            System.out.println("You have no friends.");
        } else {
            System.out.println(username + "'s friends:");
            for (int i = 0; i < friends.size(); i++) {
                System.out.println((i + 1) + ". " + friends.get(i).getUsername());
            }
        }
    }

    /**
     * Allows the user to select one friend from their friend list.
     *
     * @param scanner Scanner object for user input.
     * @return The selected User object or null if selection fails.
     */
    public User selectFriend(Scanner scanner) {
        viewFriends();
        if (friends.isEmpty()) {
            return null;
        }
        System.out.print("Select a friend by number: ");
        try {
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline
            if (choice < 1 || choice > friends.size()) {
                System.out.println("Invalid selection.");
                return null;
            }
            return friends.get(choice - 1);
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.nextLine(); // consume invalid input
            return null;
        }
    }
}